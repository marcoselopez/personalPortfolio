Encode Sans SC Variable Font
============================

This download contains Encode Sans SC as both a variable font and static fonts.

Encode Sans SC is a variable font with these axes:
  wdth
  wght

This means all the styles are contained in a single file:
  EncodeSansSC-VariableFont_wdth,wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Encode Sans SC:
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Thin.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-ExtraLight.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Light.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Regular.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Medium.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-SemiBold.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Bold.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-ExtraBold.ttf
  static/EncodeSansSC_Condensed/EncodeSansSC_Condensed-Black.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Thin.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-ExtraLight.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Light.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Regular.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Medium.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-SemiBold.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Bold.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-ExtraBold.ttf
  static/EncodeSansSC_SemiCondensed/EncodeSansSC_SemiCondensed-Black.ttf
  static/EncodeSansSC/EncodeSansSC-Thin.ttf
  static/EncodeSansSC/EncodeSansSC-ExtraLight.ttf
  static/EncodeSansSC/EncodeSansSC-Light.ttf
  static/EncodeSansSC/EncodeSansSC-Regular.ttf
  static/EncodeSansSC/EncodeSansSC-Medium.ttf
  static/EncodeSansSC/EncodeSansSC-SemiBold.ttf
  static/EncodeSansSC/EncodeSansSC-Bold.ttf
  static/EncodeSansSC/EncodeSansSC-ExtraBold.ttf
  static/EncodeSansSC/EncodeSansSC-Black.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Thin.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-ExtraLight.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Light.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Regular.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Medium.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-SemiBold.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Bold.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-ExtraBold.ttf
  static/EncodeSansSC_SemiExpanded/EncodeSansSC_SemiExpanded-Black.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Thin.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-ExtraLight.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Light.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Regular.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Medium.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-SemiBold.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Bold.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-ExtraBold.ttf
  static/EncodeSansSC_Expanded/EncodeSansSC_Expanded-Black.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them freely in your products & projects - print or digital,
commercial or otherwise. However, you can't sell the fonts on their own.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
